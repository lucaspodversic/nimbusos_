# tests/app_compat/results/

Directorio del plan NimbusOS (fase posterior).
